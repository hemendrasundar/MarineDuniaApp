package com.sun.marinedunia.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.sun.marinedunia.R;
import com.sun.marinedunia.models.QuizCategoryModel;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.viewholder> {
   private List<QuizCategoryModel> categoryModelList;

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.category_item,viewGroup,false);
   return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder viewholder, int position) {
        viewholder.setData(categoryModelList.get(position).getImageurl(),categoryModelList.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return categoryModelList.size();


    }

    class viewholder extends RecyclerView.ViewHolder{
        private CircleImageView imageView;
        private TextView title;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.category_circle_iv);
            title = itemView.findViewById(R.id.category_title_tv);
        }
        private void setData(String url,String title){
            Glide.with(itemView.getContext()).load(url).into(imageView);
            this.title.setText(title);
        }
    }
}
