
package com.sun.marinedunia;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        Toolbar toolbar = findViewById(R.id.toolbar);
        getSupportActionBar(toolbar);

    }
}
